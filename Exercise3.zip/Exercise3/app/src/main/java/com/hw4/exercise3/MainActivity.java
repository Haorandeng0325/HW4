package com.hw4.exercise3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnGo;
    private final int request = 0;
    private int clickTime = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView(){
        btnGo = findViewById(R.id.btn_go);
        btnGo.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(MainActivity.this,SecondActivity.class);
            startActivityForResult(intent,request);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(request == resultCode) {
            if (data != null) {
                if (data.getBooleanExtra("isClick", false)) {
                    clickTime++;
                    btnGo.setText(clickTime + "");
                }
            }
        }
    }
}